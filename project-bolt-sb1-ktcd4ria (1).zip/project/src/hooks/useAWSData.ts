import { useState, useEffect } from 'react';
import { 
  cloudWatchClient, 
  ec2Client, 
  s3Client, 
  rdsClient, 
  iamClient,
  commands
} from '../aws/config';
import type { Alert, AWSResource, ComplianceTask, ResourceStatus } from '../types';

export function useAWSData() {
  const [securityScore, setSecurityScore] = useState(0);
  const [activeThreats, setActiveThreats] = useState(0);
  const [compliance, setCompliance] = useState(0);
  const [vulnerabilities, setVulnerabilities] = useState(0);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [resources, setResources] = useState<AWSResource[]>([]);
  const [complianceTasks, setComplianceTasks] = useState<ComplianceTask[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch CloudWatch metrics
        const metricsResponse = await cloudWatchClient.send(commands.getMetricData);
        const securityFindings = metricsResponse.MetricDataResults?.find(
          metric => metric.Id === 'failedLogins'
        )?.Values?.[0] || 0;
        
        // Fetch EC2 instances
        const ec2Response = await ec2Client.send(commands.describeInstances);
        const instances = ec2Response.Reservations?.flatMap(r => r.Instances || []) || [];
        
        // Fetch S3 buckets
        const s3Response = await s3Client.send(commands.listBuckets);
        const buckets = s3Response.Buckets || [];
        
        // Fetch RDS instances
        const rdsResponse = await rdsClient.send(commands.describeDBInstances);
        const dbInstances = rdsResponse.DBInstances || [];
        
        // Fetch IAM users
        const iamResponse = await iamClient.send(commands.listUsers);
        const users = iamResponse.Users || [];

        // Process resources
        const awsResources: AWSResource[] = [
          ...instances.map(instance => ({
            id: instance.InstanceId!,
            name: instance.Tags?.find(t => t.Key === 'Name')?.Value || instance.InstanceId!,
            type: 'EC2' as const,
            status: instance.State?.Name === 'running' ? 'healthy' : 'warning',
            region: instance.Placement?.AvailabilityZone?.slice(0, -1) || 'unknown',
            details: {
              instanceType: instance.InstanceType
            }
          })),
          ...buckets.map(bucket => ({
            id: bucket.Name!,
            name: bucket.Name!,
            type: 'S3' as const,
            status: 'healthy',
            region: 'global',
            details: {
              created: bucket.CreationDate?.toISOString()
            }
          })),
          ...dbInstances.map(db => ({
            id: db.DBInstanceIdentifier!,
            name: db.DBInstanceIdentifier!,
            type: 'RDS' as const,
            status: db.DBInstanceStatus === 'available' ? 'healthy' : 'warning',
            region: db.AvailabilityZone?.slice(0, -1) || 'unknown',
            details: {
              instanceType: db.DBInstanceClass
            }
          }))
        ];

        // Calculate metrics
        const vulnerableResources = awsResources.filter(r => r.status !== 'healthy').length;
        const totalResources = awsResources.length;
        const securityScoreValue = Math.round(
          ((totalResources - vulnerableResources) / totalResources) * 100
        );

        // Update state
        setResources(awsResources);
        setSecurityScore(securityScoreValue);
        setActiveThreats(Math.round(securityFindings));
        setVulnerabilities(vulnerableResources);
        
        // Generate alerts based on findings
        const newAlerts: Alert[] = [];
        if (securityFindings > 0) {
          newAlerts.push({
            id: Date.now(),
            severity: 'high',
            message: `${securityFindings} security findings detected`,
            timestamp: new Date().toISOString(),
            acknowledged: false,
            service: 'EC2',
            region: 'us-east-1'
          });
        }
        
        setAlerts(prev => [...prev, ...newAlerts]);

      } catch (error) {
        console.error('Error fetching AWS data:', error);
      }
    };

    // Fetch initial data
    fetchData();

    // Set up polling every 5 minutes
    const interval = setInterval(fetchData, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  return {
    securityScore,
    activeThreats,
    compliance,
    vulnerabilities,
    alerts,
    resources,
    complianceTasks,
    setAlerts,
    setResources,
    setComplianceTasks
  };
}