import { 
  CloudWatchClient,
  GetMetricDataCommand,
  MetricDataQuery
} from "@aws-sdk/client-cloudwatch";
import { EC2Client, DescribeInstancesCommand } from "@aws-sdk/client-ec2";
import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";
import { RDSClient, DescribeDBInstancesCommand } from "@aws-sdk/client-rds";
import { IAMClient, ListUsersCommand } from "@aws-sdk/client-iam";
import { fromEnv } from "@aws-sdk/credential-providers";

// AWS Region
export const AWS_REGION = "us-east-1";

// Shared configuration for AWS clients
const sharedConfig = {
  region: AWS_REGION,
  credentials: fromEnv()
};

// Initialize AWS clients
export const cloudWatchClient = new CloudWatchClient(sharedConfig);
export const ec2Client = new EC2Client(sharedConfig);
export const s3Client = new S3Client(sharedConfig);
export const rdsClient = new RDSClient(sharedConfig);
export const iamClient = new IAMClient(sharedConfig);

// CloudWatch metric queries
export const securityMetrics: MetricDataQuery[] = [
  {
    Id: "failedLogins",
    MetricStat: {
      Metric: {
        Namespace: "AWS/CloudTrail",
        MetricName: "SecurityHubFindings",
        Dimensions: [
          {
            Name: "Severity",
            Value: "HIGH"
          }
        ]
      },
      Period: 300,
      Stat: "Sum"
    }
  },
  {
    Id: "rootActivity",
    MetricStat: {
      Metric: {
        Namespace: "AWS/CloudTrail",
        MetricName: "RootAccountUsage",
        Dimensions: []
      },
      Period: 300,
      Stat: "Sum"
    }
  }
];

// Commands
export const commands = {
  getMetricData: new GetMetricDataCommand({
    MetricDataQueries: securityMetrics,
    StartTime: new Date(Date.now() - 24 * 60 * 60 * 1000),
    EndTime: new Date()
  }),
  describeInstances: new DescribeInstancesCommand({}),
  listBuckets: new ListBucketsCommand({}),
  describeDBInstances: new DescribeDBInstancesCommand({}),
  listUsers: new ListUsersCommand({})
};