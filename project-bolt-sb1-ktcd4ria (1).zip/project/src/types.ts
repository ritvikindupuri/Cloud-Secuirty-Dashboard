export type AWSResourceType = 'EC2' | 'RDS' | 'S3' | 'VPC' | 'Lambda' | 'ECS' | 'IAM';
export type ResourceStatus = 'healthy' | 'warning' | 'critical';

export interface Alert {
  id: number;
  severity: 'high' | 'medium' | 'low';
  message: string;
  timestamp: string;
  acknowledged: boolean;
  service: AWSResourceType;
  region: string;
}

export interface AWSResource {
  id: string;
  name: string;
  type: AWSResourceType;
  status: ResourceStatus;
  region: string;
  details: {
    instanceType?: string;
    size?: string;
    accessLevel?: string;
    lastAccessed?: string;
    created?: string;
  };
}

export interface ComplianceTask {
  id: number;
  standard: string;
  task: string;
  completed: boolean;
  dueDate: string;
  awsService: AWSResourceType;
}